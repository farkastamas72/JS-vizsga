var nevek = [ [1,2,3],['alma', "banán", "körte"], {segito:"Janos", kor: 31}, "Eszter", "Bence", "Márton", "Zsófia", "Gergő", "Tamás"];

function nevCheck(callback) {
  var sajatNev = document.getElementById("sajatNev").value;
  var talalt = false;

  for (var i = 0; i < nevek.length; i++) {
    if (sajatNev.includes(nevek[i])) {
      talalt = true;
      break;
    }
  }

  callback(talalt);
}


function megjelenites(talalt) {
  var result = talalt ? "A neved szerepel az adatbázisban!" : "A neved nem szerepel az adatbázisban! Segítség: " + nevek[2].segito;
  document.getElementById("parag").innerHTML = result;

  parag.classList.remove("hidden");
  parag.classList.add("visible");
}



